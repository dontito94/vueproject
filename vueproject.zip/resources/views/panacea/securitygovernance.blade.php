@extends('layouts.app')

@section('content')
  <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row" style="backgrund-color:white;">
            <div class="col-lg-12">
                <h1 class="page-header" style="font-size:40px; line-spacing:20px; color:blue; color:red; font-weight: bold; text-align: center;">Security Governance </h1>
            </div>
        </div>
        <!-- /.row -->

        <!-- Portfolio Item Row -->
        <div class="row" style="backgrund-color:grey;" >
        <div class="col-sm-8 col-md-8 col-md-offset-2 post-content">
       <p style="font-size:20px; line-spacing:20px;"> Every Organisation has top officials be it Board of Directors or Executive Management. These officials develop organisation targets and strategies to meet those targets. That means, these officials are the most top decision makers of the organisation. Likewise, Information Security Strategy must align with and support organisation’s business objectives. However, most boards and/or executive management do not understand the importance of Information Security Management, therefore they consider it as a cost rather than an investment. With such kind of an understanding, we are here to hook up the minds of most top officials with the knowledge of Information security as one of the phenomenon towards successful governance.</p>
         
    </div>
    
            </div>
 <div class="row">
    <div class="col-md-4">
        <a href="/contact" style="text-decoration-line: none; color: white;"><button style="margin-left: 200px; margin-top: 50px; background-color: maroon; border: none; padding:10px; border-radius: 5px;">Contacts for Service</button></a>
    </div>
    <div class="col-md-4">
   <a href="/contact" style="text-decoration-line: none; color: white;"><button style="margin-left: 200px; margin-top: 50px; background-color: maroon; border: none; padding:10px; border-radius: 5px;">DownLoad PDF</button></a>
    </div>
</div>
        </div>


@endsection
